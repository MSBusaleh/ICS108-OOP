package com.example.labproject;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import static java.lang.Math.random;

public class fallingObj {
    private ImageView b1; //The burger shape
    private Timeline falling; //the falling animation
    static int strikes = 3;
    static int points = 0;

    public fallingObj() {
        //Creates the burger and adjusts its size
        b1 = new ImageView(new Image("Burger.gif"));
        b1.setFitHeight(60);
        b1.setFitWidth(60);
        spawn(b1); //puts the burger in position

        //When the burger is clicked the user gets a point and the burger re-spawn
        b1.setOnMouseClicked(e -> {spawn(b1); points++;});

        //The falling animation settings
        falling = new Timeline(new KeyFrame(Duration.millis(8.50),
                e-> {
                    if(b1.getY()==550){spawn(b1); strikes--;} //if the burger reaches the bottom a strike is counted and the burger re-spawn
                    else{b1.setY(b1.getY()+1);}})); // If the burger didn't reach the ground it keeps falling
        falling.setCycleCount(Timeline.INDEFINITE); // The cycle won't stop until stop function is called
    }

    public static void spawn(ImageView fallingObj){ //This function... well, spawns stuff
        fallingObj.setX((int)(100+ random()*800)); //The burger will be spawned in a random position
        fallingObj.setY(-100); // The burger will start from the top of the screen
    }

    // Animation control
    public void play(){
        falling.play();
    }

    public void stop(){
        b1.setY(-20);
        falling.stop();
    }

    //Getters
    public ImageView getB1() {return b1;}
    public static int getPoints() {return points;}
    public static int getStrikes() {return strikes;}
}
