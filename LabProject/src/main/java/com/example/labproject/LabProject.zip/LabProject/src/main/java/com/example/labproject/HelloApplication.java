package com.example.labproject;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {

        //These two vars will display the info <<You can play around with 'em>>
        Text strikes = new Text("Strikes: " + fallingObj.getStrikes());
        Text points = new Text("Points: " + fallingObj.getPoints());

        Pane pane = new Pane();

        //This the block will drop the objects
        fallingObj[] Burgers = new fallingObj[3]; //3 is the amount of objects
        for (fallingObj b : Burgers) {
            b = new fallingObj();
            pane.getChildren().add(b.getB1()); //This will add the Burger shape
            b.play(); //this will make the Burger fall
            }

        //<<You have to make the 
        VBox header = new VBox(strikes, points);
        pane.getChildren().add(header);

        Scene scene = new Scene(pane, 1000, 550);
        stage.setScene(scene);
        stage.setTitle("Catch Game");
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}